/* [create-plugin] version: 6.1.12 */
          /* [create-plugin] plugin: sogekng-grafanaaccessibilitycolorblind-panel@1.0.0 */
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
define(["@grafana/data","@grafana/ui","module","react"], (__WEBPACK_EXTERNAL_MODULE__grafana_data__, __WEBPACK_EXTERNAL_MODULE__grafana_ui__, __WEBPACK_EXTERNAL_MODULE_amd_module__, __WEBPACK_EXTERNAL_MODULE_react__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./components/SimplePanel.tsx":
/*!************************************!*\
  !*** ./components/SimplePanel.tsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SimplePanel: () => (/* binding */ SimplePanel)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @grafana/ui */ \"@grafana/ui\");\n/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst FILTERS = {\n    desativado: null,\n    protanopia: `1.0, 0.0, 0.0, 0, 0\n               0.0, 1.0, 0.0, 0, 0\n               0.7, 0.0, 1.0, 0, 0  \n               0,   0,   0,   1, 0`,\n    deuteranopia: `1.0, 0.0, 0.0, 0, 0\n                 0.0, 0.0, 1.0, 0, 0 \n                 0.0, 1.0, 0.0, 0, 0 \n                 0,   0,   0,   1, 0`,\n    tritanopia: `1.0, 0.0, 0.5, 0, 0  \n               0.0, 1.0, 0.0, 0, 0\n               0.0, 0.0, 0.0, 0, 0  \n               0,   0,   0,   1, 0`,\n    contrast: `2.0, -0.5, -0.5, 0, 0\n             -0.5, 2.0, -0.5, 0, 0\n             -0.5, -0.5, 2.0, 0, 0\n             0,    0,    0,   1, 0`\n};\nconst OPTIONS = [\n    {\n        label: 'Desativado',\n        value: 'desativado'\n    },\n    {\n        label: 'Protanopia',\n        value: 'protanopia'\n    },\n    {\n        label: 'Deuteranopia',\n        value: 'deuteranopia'\n    },\n    {\n        label: 'Alto Contraste',\n        value: 'contrast'\n    }\n];\nconst SimplePanel = ({ options, width, height })=>{\n    const [mode, setMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('desativado');\n    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{\n        const dashboardContainer = document.querySelector('.react-grid-layout') || document.querySelector('.main-view') || document.querySelector('.dashboard-container');\n        if (dashboardContainer) {\n            const matrix = FILTERS[mode];\n            dashboardContainer.style.filter = matrix ? `url(#correction-filter-${mode})` : 'none';\n            dashboardContainer.style.transition = 'filter 0.3s ease';\n        }\n        return ()=>{\n            if (dashboardContainer) {\n                dashboardContainer.style.filter = 'none';\n                dashboardContainer.style.transition = '';\n            }\n        };\n    }, [\n        mode\n    ]);\n    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n        style: {\n            width,\n            height,\n            display: 'flex',\n            flexDirection: 'column',\n            justifyContent: 'center',\n            alignItems: 'center',\n            padding: '10px',\n            overflow: 'hidden'\n        }\n    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.RadioButtonGroup, {\n        options: OPTIONS,\n        value: mode,\n        onChange: (v)=>setMode(v),\n        size: \"sm\"\n    }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"svg\", {\n        style: {\n            position: 'absolute',\n            height: 0,\n            width: 0,\n            overflow: 'hidden'\n        }\n    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"defs\", null, Object.entries(FILTERS).map(([key, matrix])=>matrix && /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"filter\", {\n            id: `correction-filter-${key}`,\n            key: key,\n            colorInterpolationFilters: \"sRGB\"\n        }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"feColorMatrix\", {\n            in: \"SourceGraphic\",\n            type: \"matrix\",\n            values: matrix\n        }))))));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1NpbXBsZVBhbmVsLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFtRDtBQUdKO0FBRS9DLE1BQU1JLFVBQXlDO0lBQzdDQyxZQUFZO0lBQ1pDLFlBQVksQ0FBQzs7O2tDQUdtQixDQUFDO0lBQ2pDQyxjQUFjLENBQUM7OztvQ0FHbUIsQ0FBQztJQUNuQ0MsWUFBWSxDQUFDOzs7a0NBR21CLENBQUM7SUFDakNDLFVBQVUsQ0FBQzs7O2tDQUdxQixDQUFDO0FBQ25DO0FBRUEsTUFBTUMsVUFBVTtJQUNkO1FBQUVDLE9BQU87UUFBY0MsT0FBTztJQUFhO0lBQzNDO1FBQUVELE9BQU87UUFBY0MsT0FBTztJQUFhO0lBQzNDO1FBQUVELE9BQU87UUFBZ0JDLE9BQU87SUFBZTtJQUMvQztRQUFFRCxPQUFPO1FBQWtCQyxPQUFPO0lBQVc7Q0FDOUM7QUFJTSxNQUFNQyxjQUErQixDQUFDLEVBQUVDLE9BQU8sRUFBRUMsS0FBSyxFQUFFQyxNQUFNLEVBQUU7SUFDckUsTUFBTSxDQUFDQyxNQUFNQyxRQUFRLEdBQUdqQiwrQ0FBUUEsQ0FBUztJQUV6Q0MsZ0RBQVNBLENBQUM7UUFDUixNQUFNaUIscUJBQXFCQyxTQUFTQyxhQUFhLENBQWMseUJBQzFERCxTQUFTQyxhQUFhLENBQWMsaUJBQ3BDRCxTQUFTQyxhQUFhLENBQWM7UUFFekMsSUFBSUYsb0JBQW9CO1lBQ3RCLE1BQU1HLFNBQVNsQixPQUFPLENBQUNhLEtBQUs7WUFDNUJFLG1CQUFtQkksS0FBSyxDQUFDQyxNQUFNLEdBQUdGLFNBQVMsQ0FBQyx1QkFBdUIsRUFBRUwsS0FBSyxDQUFDLENBQUMsR0FBRztZQUMvRUUsbUJBQW1CSSxLQUFLLENBQUNFLFVBQVUsR0FBRztRQUN4QztRQUVBLE9BQU87WUFDTCxJQUFJTixvQkFBb0I7Z0JBQ3RCQSxtQkFBbUJJLEtBQUssQ0FBQ0MsTUFBTSxHQUFHO2dCQUNsQ0wsbUJBQW1CSSxLQUFLLENBQUNFLFVBQVUsR0FBRztZQUN4QztRQUNGO0lBQ0YsR0FBRztRQUFDUjtLQUFLO0lBRVQscUJBQ0UsMkRBQUNTO1FBQ0NILE9BQU87WUFDTFI7WUFDQUM7WUFDQVcsU0FBUztZQUNUQyxlQUFlO1lBQ2ZDLGdCQUFnQjtZQUNoQkMsWUFBWTtZQUNaQyxTQUFTO1lBQ1RDLFVBQVU7UUFDWjtxQkFHQSwyREFBQzdCLHlEQUFnQkE7UUFDZlcsU0FBU0o7UUFDVEUsT0FBT0s7UUFDUGdCLFVBQVUsQ0FBQ0MsSUFBTWhCLFFBQVFnQjtRQUN6QkMsTUFBSztzQkFHUCwyREFBQ0M7UUFBSWIsT0FBTztZQUFFYyxVQUFVO1lBQVlyQixRQUFRO1lBQUdELE9BQU87WUFBR2lCLFVBQVU7UUFBUztxQkFDMUUsMkRBQUNNLGNBQ0VDLE9BQU9DLE9BQU8sQ0FBQ3BDLFNBQVNxQyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxLQUFLcEIsT0FBTyxHQUN6Q0Esd0JBQ0UsMkRBQUNFO1lBQU9tQixJQUFJLENBQUMsa0JBQWtCLEVBQUVELEtBQUs7WUFBRUEsS0FBS0E7WUFBS0UsMkJBQTBCO3lCQUMxRSwyREFBQ0M7WUFBY0MsSUFBRztZQUFnQkMsTUFBSztZQUFTQyxRQUFRMUI7O0FBUXhFLEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zb2dla25nLWdyYWZhbmFhY2Nlc3NpYmlsaXR5Y29sb3JibGluZC1wYW5lbC8uL2NvbXBvbmVudHMvU2ltcGxlUGFuZWwudHN4PzIyMWMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBQYW5lbFByb3BzIH0gZnJvbSAnQGdyYWZhbmEvZGF0YSc7XG5pbXBvcnQgeyBTaW1wbGVPcHRpb25zIH0gZnJvbSAndHlwZXMnO1xuaW1wb3J0IHsgUmFkaW9CdXR0b25Hcm91cCB9IGZyb20gJ0BncmFmYW5hL3VpJztcblxuY29uc3QgRklMVEVSUzogUmVjb3JkPHN0cmluZywgc3RyaW5nIHwgbnVsbD4gPSB7XG4gIGRlc2F0aXZhZG86IG51bGwsXG4gIHByb3Rhbm9waWE6IGAxLjAsIDAuMCwgMC4wLCAwLCAwXG4gICAgICAgICAgICAgICAwLjAsIDEuMCwgMC4wLCAwLCAwXG4gICAgICAgICAgICAgICAwLjcsIDAuMCwgMS4wLCAwLCAwICBcbiAgICAgICAgICAgICAgIDAsICAgMCwgICAwLCAgIDEsIDBgLFxuICBkZXV0ZXJhbm9waWE6IGAxLjAsIDAuMCwgMC4wLCAwLCAwXG4gICAgICAgICAgICAgICAgIDAuMCwgMC4wLCAxLjAsIDAsIDAgXG4gICAgICAgICAgICAgICAgIDAuMCwgMS4wLCAwLjAsIDAsIDAgXG4gICAgICAgICAgICAgICAgIDAsICAgMCwgICAwLCAgIDEsIDBgLFxuICB0cml0YW5vcGlhOiBgMS4wLCAwLjAsIDAuNSwgMCwgMCAgXG4gICAgICAgICAgICAgICAwLjAsIDEuMCwgMC4wLCAwLCAwXG4gICAgICAgICAgICAgICAwLjAsIDAuMCwgMC4wLCAwLCAwICBcbiAgICAgICAgICAgICAgIDAsICAgMCwgICAwLCAgIDEsIDBgLFxuICBjb250cmFzdDogYDIuMCwgLTAuNSwgLTAuNSwgMCwgMFxuICAgICAgICAgICAgIC0wLjUsIDIuMCwgLTAuNSwgMCwgMFxuICAgICAgICAgICAgIC0wLjUsIC0wLjUsIDIuMCwgMCwgMFxuICAgICAgICAgICAgIDAsICAgIDAsICAgIDAsICAgMSwgMGBcbn07XG5cbmNvbnN0IE9QVElPTlMgPSBbXG4gIHsgbGFiZWw6ICdEZXNhdGl2YWRvJywgdmFsdWU6ICdkZXNhdGl2YWRvJyB9LFxuICB7IGxhYmVsOiAnUHJvdGFub3BpYScsIHZhbHVlOiAncHJvdGFub3BpYScgfSxcbiAgeyBsYWJlbDogJ0RldXRlcmFub3BpYScsIHZhbHVlOiAnZGV1dGVyYW5vcGlhJyB9LFxuICB7IGxhYmVsOiAnQWx0byBDb250cmFzdGUnLCB2YWx1ZTogJ2NvbnRyYXN0JyB9LFxuXTtcblxuaW50ZXJmYWNlIFByb3BzIGV4dGVuZHMgUGFuZWxQcm9wczxTaW1wbGVPcHRpb25zPiB7fVxuXG5leHBvcnQgY29uc3QgU2ltcGxlUGFuZWw6IFJlYWN0LkZDPFByb3BzPiA9ICh7IG9wdGlvbnMsIHdpZHRoLCBoZWlnaHQgfSkgPT4ge1xuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdkZXNhdGl2YWRvJyk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBkYXNoYm9hcmRDb250YWluZXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PignLnJlYWN0LWdyaWQtbGF5b3V0JylcbiAgICAgIHx8IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KCcubWFpbi12aWV3JylcbiAgICAgIHx8IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KCcuZGFzaGJvYXJkLWNvbnRhaW5lcicpO1xuXG4gICAgaWYgKGRhc2hib2FyZENvbnRhaW5lcikge1xuICAgICAgY29uc3QgbWF0cml4ID0gRklMVEVSU1ttb2RlXTtcbiAgICAgIGRhc2hib2FyZENvbnRhaW5lci5zdHlsZS5maWx0ZXIgPSBtYXRyaXggPyBgdXJsKCNjb3JyZWN0aW9uLWZpbHRlci0ke21vZGV9KWAgOiAnbm9uZSc7XG4gICAgICBkYXNoYm9hcmRDb250YWluZXIuc3R5bGUudHJhbnNpdGlvbiA9ICdmaWx0ZXIgMC4zcyBlYXNlJztcbiAgICB9XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKGRhc2hib2FyZENvbnRhaW5lcikge1xuICAgICAgICBkYXNoYm9hcmRDb250YWluZXIuc3R5bGUuZmlsdGVyID0gJ25vbmUnO1xuICAgICAgICBkYXNoYm9hcmRDb250YWluZXIuc3R5bGUudHJhbnNpdGlvbiA9ICcnO1xuICAgICAgfVxuICAgIH07XG4gIH0sIFttb2RlXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBzdHlsZT17e1xuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICBwYWRkaW5nOiAnMTBweCcsXG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJ1xuICAgICAgfX1cbiAgICA+XG5cbiAgICAgIDxSYWRpb0J1dHRvbkdyb3VwXG4gICAgICAgIG9wdGlvbnM9e09QVElPTlN9XG4gICAgICAgIHZhbHVlPXttb2RlfVxuICAgICAgICBvbkNoYW5nZT17KHYpID0+IHNldE1vZGUodiEpfVxuICAgICAgICBzaXplPVwic21cIlxuICAgICAgLz5cblxuICAgICAgPHN2ZyBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgaGVpZ2h0OiAwLCB3aWR0aDogMCwgb3ZlcmZsb3c6ICdoaWRkZW4nIH19PlxuICAgICAgICA8ZGVmcz5cbiAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoRklMVEVSUykubWFwKChba2V5LCBtYXRyaXhdKSA9PiAoXG4gICAgICAgICAgICBtYXRyaXggJiYgKFxuICAgICAgICAgICAgICA8ZmlsdGVyIGlkPXtgY29ycmVjdGlvbi1maWx0ZXItJHtrZXl9YH0ga2V5PXtrZXl9IGNvbG9ySW50ZXJwb2xhdGlvbkZpbHRlcnM9XCJzUkdCXCI+XG4gICAgICAgICAgICAgICAgPGZlQ29sb3JNYXRyaXggaW49XCJTb3VyY2VHcmFwaGljXCIgdHlwZT1cIm1hdHJpeFwiIHZhbHVlcz17bWF0cml4fSAvPlxuICAgICAgICAgICAgICA8L2ZpbHRlcj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kZWZzPlxuICAgICAgPC9zdmc+XG4gICAgPC9kaXY+XG4gICk7XG59OyJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiUmFkaW9CdXR0b25Hcm91cCIsIkZJTFRFUlMiLCJkZXNhdGl2YWRvIiwicHJvdGFub3BpYSIsImRldXRlcmFub3BpYSIsInRyaXRhbm9waWEiLCJjb250cmFzdCIsIk9QVElPTlMiLCJsYWJlbCIsInZhbHVlIiwiU2ltcGxlUGFuZWwiLCJvcHRpb25zIiwid2lkdGgiLCJoZWlnaHQiLCJtb2RlIiwic2V0TW9kZSIsImRhc2hib2FyZENvbnRhaW5lciIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvciIsIm1hdHJpeCIsInN0eWxlIiwiZmlsdGVyIiwidHJhbnNpdGlvbiIsImRpdiIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwianVzdGlmeUNvbnRlbnQiLCJhbGlnbkl0ZW1zIiwicGFkZGluZyIsIm92ZXJmbG93Iiwib25DaGFuZ2UiLCJ2Iiwic2l6ZSIsInN2ZyIsInBvc2l0aW9uIiwiZGVmcyIsIk9iamVjdCIsImVudHJpZXMiLCJtYXAiLCJrZXkiLCJpZCIsImNvbG9ySW50ZXJwb2xhdGlvbkZpbHRlcnMiLCJmZUNvbG9yTWF0cml4IiwiaW4iLCJ0eXBlIiwidmFsdWVzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/SimplePanel.tsx\n\n}");

/***/ }),

/***/ "./module.ts":
/*!*******************!*\
  !*** ./module.ts ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   plugin: () => (/* binding */ plugin)\n/* harmony export */ });\n/* harmony import */ var grafana_public_path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! grafana-public-path */ \"./node_modules/grafana-public-path.js\");\n/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @grafana/data */ \"@grafana/data\");\n/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_SimplePanel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/SimplePanel */ \"./components/SimplePanel.tsx\");\n/*** IMPORTS FROM imports-loader ***/\n\n\n\n\nconst plugin = new _grafana_data__WEBPACK_IMPORTED_MODULE_1__.PanelPlugin(_components_SimplePanel__WEBPACK_IMPORTED_MODULE_2__.SimplePanel).setPanelOptions((builder)=>{\n    return builder.addTextInput({\n        path: 'text',\n        name: 'Simple text option',\n        description: 'Description of panel option',\n        defaultValue: 'Default value of text input option'\n    }).addBooleanSwitch({\n        path: 'showSeriesCount',\n        name: 'Show series counter',\n        defaultValue: false\n    }).addRadio({\n        path: 'seriesCountSize',\n        defaultValue: 'sm',\n        name: 'Series counter size',\n        settings: {\n            options: [\n                {\n                    value: 'sm',\n                    label: 'Small'\n                },\n                {\n                    value: 'md',\n                    label: 'Medium'\n                },\n                {\n                    value: 'lg',\n                    label: 'Large'\n                }\n            ]\n        },\n        showIf: (config)=>config.showSeriesCount\n    });\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9tb2R1bGUudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBNEM7QUFFVztBQUVoRCxNQUFNRSxTQUFTLElBQUlGLHNEQUFXQSxDQUFnQkMsZ0VBQVdBLEVBQUVFLGVBQWUsQ0FBQyxDQUFDQztJQUNqRixPQUFPQSxRQUNKQyxZQUFZLENBQUM7UUFDWkMsTUFBTTtRQUNOQyxNQUFNO1FBQ05DLGFBQWE7UUFDYkMsY0FBYztJQUNoQixHQUNDQyxnQkFBZ0IsQ0FBQztRQUNoQkosTUFBTTtRQUNOQyxNQUFNO1FBQ05FLGNBQWM7SUFDaEIsR0FDQ0UsUUFBUSxDQUFDO1FBQ1JMLE1BQU07UUFDTkcsY0FBYztRQUNkRixNQUFNO1FBQ05LLFVBQVU7WUFDUkMsU0FBUztnQkFDUDtvQkFDRUMsT0FBTztvQkFDUEMsT0FBTztnQkFDVDtnQkFDQTtvQkFDRUQsT0FBTztvQkFDUEMsT0FBTztnQkFDVDtnQkFDQTtvQkFDRUQsT0FBTztvQkFDUEMsT0FBTztnQkFDVDthQUNEO1FBQ0g7UUFDQUMsUUFBUSxDQUFDQyxTQUFXQSxPQUFPQyxlQUFlO0lBQzVDO0FBQ0osR0FBRyIsInNvdXJjZXMiOlsid2VicGFjazovL3NvZ2VrbmctZ3JhZmFuYWFjY2Vzc2liaWxpdHljb2xvcmJsaW5kLXBhbmVsLy4vbW9kdWxlLnRzP2MyMTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFuZWxQbHVnaW4gfSBmcm9tICdAZ3JhZmFuYS9kYXRhJztcbmltcG9ydCB7IFNpbXBsZU9wdGlvbnMgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IFNpbXBsZVBhbmVsIH0gZnJvbSAnLi9jb21wb25lbnRzL1NpbXBsZVBhbmVsJztcblxuZXhwb3J0IGNvbnN0IHBsdWdpbiA9IG5ldyBQYW5lbFBsdWdpbjxTaW1wbGVPcHRpb25zPihTaW1wbGVQYW5lbCkuc2V0UGFuZWxPcHRpb25zKChidWlsZGVyKSA9PiB7XG4gIHJldHVybiBidWlsZGVyXG4gICAgLmFkZFRleHRJbnB1dCh7XG4gICAgICBwYXRoOiAndGV4dCcsXG4gICAgICBuYW1lOiAnU2ltcGxlIHRleHQgb3B0aW9uJyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnRGVzY3JpcHRpb24gb2YgcGFuZWwgb3B0aW9uJyxcbiAgICAgIGRlZmF1bHRWYWx1ZTogJ0RlZmF1bHQgdmFsdWUgb2YgdGV4dCBpbnB1dCBvcHRpb24nLFxuICAgIH0pXG4gICAgLmFkZEJvb2xlYW5Td2l0Y2goe1xuICAgICAgcGF0aDogJ3Nob3dTZXJpZXNDb3VudCcsXG4gICAgICBuYW1lOiAnU2hvdyBzZXJpZXMgY291bnRlcicsXG4gICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlLFxuICAgIH0pXG4gICAgLmFkZFJhZGlvKHtcbiAgICAgIHBhdGg6ICdzZXJpZXNDb3VudFNpemUnLFxuICAgICAgZGVmYXVsdFZhbHVlOiAnc20nLFxuICAgICAgbmFtZTogJ1NlcmllcyBjb3VudGVyIHNpemUnLFxuICAgICAgc2V0dGluZ3M6IHtcbiAgICAgICAgb3B0aW9uczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIHZhbHVlOiAnc20nLFxuICAgICAgICAgICAgbGFiZWw6ICdTbWFsbCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICB2YWx1ZTogJ21kJyxcbiAgICAgICAgICAgIGxhYmVsOiAnTWVkaXVtJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHZhbHVlOiAnbGcnLFxuICAgICAgICAgICAgbGFiZWw6ICdMYXJnZScsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0sXG4gICAgICBzaG93SWY6IChjb25maWcpID0+IGNvbmZpZy5zaG93U2VyaWVzQ291bnQsXG4gICAgfSk7XG59KTtcbiJdLCJuYW1lcyI6WyJQYW5lbFBsdWdpbiIsIlNpbXBsZVBhbmVsIiwicGx1Z2luIiwic2V0UGFuZWxPcHRpb25zIiwiYnVpbGRlciIsImFkZFRleHRJbnB1dCIsInBhdGgiLCJuYW1lIiwiZGVzY3JpcHRpb24iLCJkZWZhdWx0VmFsdWUiLCJhZGRCb29sZWFuU3dpdGNoIiwiYWRkUmFkaW8iLCJzZXR0aW5ncyIsIm9wdGlvbnMiLCJ2YWx1ZSIsImxhYmVsIiwic2hvd0lmIiwiY29uZmlnIiwic2hvd1Nlcmllc0NvdW50Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./module.ts\n\n}");

/***/ }),

/***/ "./node_modules/grafana-public-path.js":
/*!*********************************************!*\
  !*** ./node_modules/grafana-public-path.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var amd_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! amd-module */ \"amd-module\");\n/* harmony import */ var amd_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(amd_module__WEBPACK_IMPORTED_MODULE_0__);\n\n\n\n__webpack_require__.p =\n  (amd_module__WEBPACK_IMPORTED_MODULE_0___default()) && (amd_module__WEBPACK_IMPORTED_MODULE_0___default().uri)\n    ? amd_module__WEBPACK_IMPORTED_MODULE_0___default().uri.slice(0, amd_module__WEBPACK_IMPORTED_MODULE_0___default().uri.lastIndexOf('/') + 1)\n    : 'public/plugins/sogekng-grafanaaccessibilitycolorblind-panel/';\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvZ3JhZmFuYS1wdWJsaWMtcGF0aC5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQ3VDOztBQUV2QyxxQkFBdUI7QUFDdkIsRUFBRSxtREFBYSxJQUFJLHVEQUFpQjtBQUNwQyxNQUFNLHFEQUFpQixVQUFVLHFEQUFpQjtBQUNsRCIsInNvdXJjZXMiOlsid2VicGFjazovL3NvZ2VrbmctZ3JhZmFuYWFjY2Vzc2liaWxpdHljb2xvcmJsaW5kLXBhbmVsLy4vbm9kZV9tb2R1bGVzL2dyYWZhbmEtcHVibGljLXBhdGguanM/OTNlMyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCBhbWRNZXRhTW9kdWxlIGZyb20gJ2FtZC1tb2R1bGUnO1xuXG5fX3dlYnBhY2tfcHVibGljX3BhdGhfXyA9XG4gIGFtZE1ldGFNb2R1bGUgJiYgYW1kTWV0YU1vZHVsZS51cmlcbiAgICA/IGFtZE1ldGFNb2R1bGUudXJpLnNsaWNlKDAsIGFtZE1ldGFNb2R1bGUudXJpLmxhc3RJbmRleE9mKCcvJykgKyAxKVxuICAgIDogJ3B1YmxpYy9wbHVnaW5zL3NvZ2VrbmctZ3JhZmFuYWFjY2Vzc2liaWxpdHljb2xvcmJsaW5kLXBhbmVsLyc7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./node_modules/grafana-public-path.js\n\n}");

/***/ }),

/***/ "@grafana/data":
/*!********************************!*\
  !*** external "@grafana/data" ***!
  \********************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_data__;

/***/ }),

/***/ "@grafana/ui":
/*!******************************!*\
  !*** external "@grafana/ui" ***!
  \******************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_ui__;

/***/ }),

/***/ "amd-module":
/*!*************************!*\
  !*** external "module" ***!
  \*************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE_amd_module__;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE_react__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "public/plugins/sogekng-grafanaaccessibilitycolorblind-panel/";
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./module.ts");
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});;